# DM de NSI sur le CSS et l'HTML
## TORO Nicolas 1G03
    
Bonjour Monsieur, vous trouverez ici deux dossier.    
Le premier qui se nomme "projet" et qui est composé backup ou d'autre fichier inutile au bon déroulement du site tel que le fichier "style.scss".    
Et enfin, vous trouverez le dossier "Version finale" qui est la version finale de mon site ainsi que quelque explication sur mon projet.    
J'espère qu'il conviendra à vos attente.    
Cordialement, TORO Nicolas 1G03    