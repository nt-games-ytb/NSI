# DM de NSI sur le CSS par Nicolas TORO

## Information
- Logiciel : Visual Studio Code 
+ Entension : vscode-pdf + PDF Preview + Jupyter 
- Google exentension : [Auto Refresh Plus | Page Monitor](https://chrome.google.com/webstore/detail/auto-refresh-plus-page-mo/hgeljhfekpckiiplhkigfehkdpldcggm/related?hl=fr)

## Idée
- Faire un site sur le csharp
- mettre des exemples
- categories : 10
    1 - c'est quoi le csharp
    2 - on experience personnel
    3 - les différents logiciels
    4 - les meilleures exentension
    5 - le design facile
    6 - les defaults du csharp
    7 - comment proteger son code (peut-être mettre un ptit tuto [change la taille comparer à celui de en dessous])
    8 - des tutoriels
    9 - Problème ? Besoin d'aide (add des fake com) [avec js]
    10 - contact/crédits
- Faire un petit peu de js
- faire un dark mode ---> switch vert

## Présentation

| Gros en-tête/Gros titre centré |
| Navigation en les trucs |
| 1 | 2 |
| 3 | 4 | 5 |
| 6 | 7 |
| 8 |
| 9 | 10 |
| Footer avec mini navigation |

## Visuel

- la page sera blanche de base et en dark mode sera maybe #303030
- gros titre = mediumslateblue
- text basique = seagreen
- peut-être faire des section en mode bloc vert avec bodure comme text et fond plus clair ---> 1,2,4,6,7 ou 3,5
- en tête --> black black
- navigation ---> black moins black + boutton blanc arrondi avec de l'ombre

## à faire
[] Pour le hamburgeur : 
    - https://www.w3schools.com/howto/tryit.asp?filename=tryhow_js_mobile_navbar
    - https://www.w3schools.com/howto/howto_js_mobile_navbar.asp
    - https://jenseign.com/apprendre-html-css/pratique-exemple/menu-burger/
[] Ré organiser tout et tout
[] Finir l'en-tête
[] Faire les textes
[] Le reste

## Objectifs
[] Créer un site internet 
[X] sur le sujet de votre choix (le csharp)
[X] avec une page de style css
[X] qui organisera la page principale en 4 blocs minimum
[X] au moins 2 tableaux
[] 5 images
[] plusieurs liens.